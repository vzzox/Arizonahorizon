
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <>
      <Head>
        <title>Arizona Horizon</title>
      </Head>
      <main style={{padding:40, color:'#fff', background:'#0b0b0b', minHeight:'100vh'}}>
        <h1>Arizona Horizon</h1>
        <p>Official SAMP Server</p>
        <p>IP: 185.207.214.14:2489</p>
        <Link href="https://discord.gg/2pmv4txHTe">Discord</Link>
      </main>
    </>
  );
}
