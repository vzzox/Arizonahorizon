
import type { NextApiRequest, NextApiResponse } from 'next';
import bcrypt from 'bcryptjs';
import { pool } from '../../../lib/db';
import { signAccessToken, signRefreshToken } from '../../../lib/auth';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const { email, password } = req.body;
  const { rows } = await pool.query('SELECT u.*, r.name as role FROM users u JOIN roles r ON r.id=u.role_id WHERE email=$1', [email]);

  if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });

  const user = rows[0];
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

  const access = signAccessToken({ id: user.id, role: user.role });
  const refresh = signRefreshToken({ id: user.id });

  res.json({ access, refresh });
}
