
# Arizona Horizon — Official SAMP Server Website

Production-ready full-stack project for SAMP server **Arizona Horizon**.

## Stack
- Next.js (Pages Router)
- Cloudflare Pages / Functions compatible
- PostgreSQL (Supabase / Neon)
- JWT Auth (Access + Refresh)
- Role-Based Access Control
- Full Admin Panel
- Multilanguage (RU / EN / UA / KZ)

## Server
IP: 185.207.214.14  
Port: 2489  
Discord: https://discord.gg/2pmv4txHTe

## Setup
1. Copy `.env.example` to `.env`
2. Configure database & JWT secrets
3. Run migrations from `database/schema.sql`
4. Deploy to Cloudflare Pages

## Roles
Owner, Admin, Helper, User  
Owner has full control including role creation.

## Security
- JWT
- CAPTCHA ready
- Rate limiting hooks
- RBAC middleware
